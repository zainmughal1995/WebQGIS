import { useDispatch, useSelector } from "react-redux";
import { openRightPanel, closeRightPanel } from "../store/uiSlice";
import { useState } from "react";

/* ---------------- TREE ---------------- */

const TREE = [
  { name: "Recently used" },

  {
    name: "3D Tiles",
    children: ["Convert B3DM to GLTF", "Convert GLTF to vector features"],
  },

  {
    name: "Cartography",
    children: [
      "Align points to features",
      "Combine style databases",
      "Create categorized renderer from styles",
      "create style database from project",
    ],
  },

  { name: "Database", children: ["Export to PostgreSQL"] },
  { name: "File tools" },
  { name: "GPS" },
  { name: "Interpolation" },
  { name: "Layer tools" },
  { name: "Mesh" },
  { name: "Network analysis" },
  { name: "Raster analysis" },
  { name: "Raster tools" },
  { name: "Vector analysis" },
  { name: "Vector creation" },
  { name: "Vector geometry" },
  { name: "Vector overlay" },
  { name: "Vector selection" },
  { name: "GDAL" },
  { name: "GRASS" },
];

/* ---------------- ROW ---------------- */

function Row({ item, search }) {
  const [open, setOpen] = useState(false);

  const s = search.toLowerCase();

  const categoryMatch = item.name.toLowerCase().includes(s);

  const matchedChildren =
    item.children?.filter((c) => c.toLowerCase().includes(s)) || [];

  if (search && !categoryMatch && matchedChildren.length === 0) return null;

  const showChildren = open || (search && matchedChildren.length);

  // No children
  if (!item.children) {
    if (!search || categoryMatch)
      return (
        <div className="px-3 py-[3px] hover:bg-[#dcdcdc] cursor-default">
          ▸ {item.name}
        </div>
      );
    return null;
  }

  return (
    <div>
      <div
        onClick={() => setOpen(!open)}
        className="px-3 py-[3px] hover:bg-[#dcdcdc] cursor-pointer select-none"
      >
        {showChildren ? "▾" : "▸"} {item.name}
      </div>

      {showChildren && (
        <div>
          {(search ? matchedChildren : item.children).map((c) => (
            <div
              key={c}
              className="px-8 py-[3px] hover:bg-[#dcdcdc] cursor-pointer"
            >
              ⚙ {c}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------------- TREE VIEW ---------------- */

function ProcessingTree({ search }) {
  return (
    <div className="text-[13px]">
      {TREE.map((i) => (
        <Row key={i.name} item={i} search={search} />
      ))}
    </div>
  );
}

/* ---------------- MAIN PANEL ---------------- */

export default function RightPanel() {
  const dispatch = useDispatch();
  const open = useSelector((s) => s.ui.rightPanelOpen);

  const [search, setSearch] = useState("");

  if (!open) {
    return (
      <div className="h-full w-1 flex">
        <div
          onClick={() => dispatch(openRightPanel())}
          className="
            w-6 h-full
            bg-[#e9e9e9]
            border-l border-[#cfcfcf]
            flex items-center justify-center
            cursor-pointer text-[12px]
            shrink-0
          "
          style={{ writingMode: "vertical-rl" }}
        >
          Processing
        </div>
      </div>
    );
  }

  return (
    <div
      className="
      w-[300px] h-full
      bg-[#f0f0f0]
      border-l border-[#cfcfcf]
      flex flex-col
    "
    >
      {/* Header */}
      <div className="h-7 bg-[#e9e9e9] border-b border-[#cfcfcf] flex items-center justify-between px-2 text-[13px]">
        <span>Processing Toolbox</span>
        <button
          onClick={() => dispatch(closeRightPanel())}
          className="px-1 hover:bg-[#dcdcdc]"
        >
          ✕
        </button>
      </div>

      {/* Search */}
      <div className="p-2 border-b border-[#cfcfcf] bg-[#f5f5f5]">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search..."
          className="
            w-full border border-[#cfcfcf]
            px-2 py-1 text-[13px]
            outline-none focus:border-[#2b79c2]
          "
        />
      </div>

      {/* Tree */}
      <div className="flex-1 overflow-auto bg-[#f7f7f7]">
        <ProcessingTree search={search} />
      </div>
    </div>
  );
}
