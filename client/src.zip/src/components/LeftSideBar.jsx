import { useState } from "react";
import { useDispatch } from "react-redux";
import { setBasemap } from "../store/uiSlice";
import LayersPanel from "./LayersPanel";

/* Panel */

function Panel({ title, children, defaultOpen = true }) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="border-b border-[#cfcfcf]">
      <div
        onClick={() => setOpen(!open)}
        className="h-7 px-2 flex justify-between items-center bg-[#e9e9e9] text-[13px] cursor-pointer hover:bg-[#dedede]"
      >
        <span>{title}</span>
        <span>{open ? "▾" : "▸"}</span>
      </div>

      {open && <div className="bg-[#f5f5f5]">{children}</div>}
    </div>
  );
}

/* Browser */

function BrowserTree() {
  const dispatch = useDispatch();
  const [wmsOpen, setWmsOpen] = useState(false);

  return (
    <div className="py-1 text-[13px]">
      {[
        "Favorites",
        "Spatial Bookmarks",
        "Home",
        "C:",
        "GeoPackage",
        "SpatiaLite",
        "PostgreSQL",
      ].map((i) => (
        <div key={i} className="px-3 py-[3px] hover:bg-[#dcdcdc]">
          ▸ {i}
        </div>
      ))}

      {/* WMS */}
      <div
        onClick={() => setWmsOpen(!wmsOpen)}
        className="px-3 py-[3px] hover:bg-[#dcdcdc] cursor-pointer"
      >
        {wmsOpen ? "▾" : "▸"} WMS/WMTS
      </div>

      {wmsOpen && (
        <div className="ml-4">
          <Item
            label="OpenStreetMap"
            onClick={() => dispatch(setBasemap("osm"))}
          />
          <Item label="Satellite" onClick={() => dispatch(setBasemap("sat"))} />
          <Item
            label="Topographic"
            onClick={() => dispatch(setBasemap("topo"))}
          />
        </div>
      )}

      <div className="px-3 py-[3px] hover:bg-[#dcdcdc]">▸ Cloud</div>
    </div>
  );
}

function Item({ label, onClick }) {
  return (
    <div
      onClick={onClick}
      className="px-3 py-[3px] hover:bg-[#dcdcdc] cursor-pointer"
    >
      🌐 {label}
    </div>
  );
}

/* Sidebar */

export default function LeftSidebar() {
  return (
    <div className="w-[260px] h-full bg-[#f0f0f0] border-r border-[#cfcfcf] flex flex-col">
      <Panel title="Browser">
        <BrowserTree />
        <LayersPanel />
      </Panel>
    </div>
  );
}
